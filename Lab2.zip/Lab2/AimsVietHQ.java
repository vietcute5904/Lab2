public class AimsVietHQ {
    public static void main(String[] args) {
        //Create new cart
        CartVietHQ anOrder = new CartVietHQ();

        //Create new DVD and add to cart
        DVDVietHQ DVD1 = new DVDVietHQ("Lion King", "Animation", "Roger Allers", 87, 19.95f);
        anOrder.addDVDVhq(DVD1);
        DVDVietHQ DVD2 = new DVDVietHQ("Star Wars", "Science Fiction", "Geogre Lucas", 87,  24.95f);
        anOrder.addDVDVhq(DVD2);
        DVDVietHQ DVD3 = new DVDVietHQ("Aladin", "Animation", 18.99f);
        anOrder.addDVDVhq(DVD3);

        //Print total cost of DVDs in cart
        System.out.println("Total cost is: " + anOrder.totalCostVhq() + "$");

        //Remove DVD
        anOrder.removeDVDVhq(DVD3);

        //Print total cost of the DVDs in the cart after remove DVD
        System.out.println("Total cost is: " + anOrder.totalCostVhq() + "$");
        
    }
}
