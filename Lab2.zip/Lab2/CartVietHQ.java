public class CartVietHQ {
    public static final int MAX_NUMBERS_ORDERED = 20;
    private DVDVietHQ itemsOrdered[] = new DVDVietHQ[MAX_NUMBERS_ORDERED];

    private int qtyOrdered = 0;

    //Add DVD
    public void addDVDVhq(DVDVietHQ disc) {
        if(qtyOrdered < 20) {
            itemsOrdered[qtyOrdered] = disc;
            qtyOrdered++;
            System.out.println("The DVD " + '\"' + disc.getTitleVhq() + '\"' + " has been added!");
        } else {
            System.out.println("Your cart is full, can not add more!");
        }
    }

    //Remove DVD 
    public void removeDVDVhq(DVDVietHQ disc) {
        if(itemsOrdered[0] == null) {
            System.out.println("Your cart is empty!"); return ;
        }
        for(int i=0; i<qtyOrdered; i++){
            if(itemsOrdered[i].getTitleVhq().equals(disc.getTitleVhq())){
                for(int j=i; j<qtyOrdered-1; j++){
                    itemsOrdered[j] = itemsOrdered[j+1];
                }
                itemsOrdered[qtyOrdered-1] = null;
                qtyOrdered--;
                System.out.println("Remove DVD " + '\"' + disc.getTitleVhq() + '\"' + " successfully!");
                break;
            }
        }
    }

    //Caculate total cost
    public float totalCostVhq(){
        float total = 0;
        for(int i=0; i<qtyOrdered; i++){
            total += itemsOrdered[i].getCostVhq();
        }
        return total;
    }
}
